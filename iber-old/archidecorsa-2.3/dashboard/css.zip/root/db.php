<?php
$servername="localhost";
$username="iberrtech_catalyst";
$password="iberrtech_catalyst";
$dbname="iberrtech_catalyst";

$mysqli= new mysqli($servername,$username,$password,$dbname);
if($mysqli->connect_error){
    die ("connectio faild:" . $mysqli->connect_error);
}
define('BASE_URL', 'http://localhost/archidecorsa');
?>

